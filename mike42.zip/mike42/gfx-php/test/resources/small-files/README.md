# Small files

These test files were produded for `escpos-php`.

The same file should have the same representation in black & white from any source format.

