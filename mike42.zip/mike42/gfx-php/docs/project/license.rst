License
=======

.. literalinclude:: ../../LICENSE
